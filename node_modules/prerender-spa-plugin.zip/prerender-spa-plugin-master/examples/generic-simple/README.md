# Generic & Simple Example

The simplest possible example of a prerendered static site, using JavaScript with no external libraries.

## Usage

```
cd path/to/examples/generic-simple
npm install
npm run build
```

Now check the new `dist` directory for your prerendered static site! You'll notice that the initial todos have been prerendered on the page.
